<!DOCTYPE html>
<html>
<head>
	<title>PEMERAN AVANGER</title>
	<style>
		.kotak {
			width: 30px;
			height: 30px;
			background-color: #BADA55;
			text-align: center;
			line-height: 30px;
			margin: 3px; 
			float: left;
			transition: 1s;
		}
		.kotak:hover {
			transform: rotate(180deg);
			border-radius: 50%;
		}
		.clear {
			clear : both;
		}

	</style>
</head>
<body>

<?php $jd =["P", "E", "M", "E","R", "A", "N", "", "T", "H", "E","", "A", "V", "E", "N", "G", "E", "R", "S"];
?>

<?php foreach( $jd as $l ) : ?>
		<div class="kotak"><?= $l ?></div>
	<?php endforeach; ?>
<br>
<br>
<h5>DATA PEMERAN AVENGERS END GAME:</h5>

<?php $pmr =[
	[
		"nama" => "Robert Downey Jr", 
		"sebagai" => "Tony Stark",
		"superhero" => "Iron Man", 
		"negara" => "Amerika Serikat",
		"gambar" => "robert.jpg"
	],
	[
		"nama" => "Chris Evans", 
		"sebagai" => "Stive Roger",
		"superhero" => "Captain America", 
		"negara" => "Amerika Serikat",
		"gambar" => "chris.jpg"
	],
	[
		"nama" => "Chris Hemsworth", 
		"sebagai" => "Thor Odinson",
		"superhero" => "Thor", 
		"negara" => "Australia",
		"gambar" => "hemsworth.jpg"
		],
	[
		"nama" => "Scarlett Johannson", 
		"sebagai" => "Natasha Romanoff",
		"superhero" => "Black Widow", 
		"negara" => "Amerika Serikat",
		"gambar" => "scarlett.jpg"
	],
	[
		"nama" => "Brie Larson", 
		"sebagai" => "Carol Danvers",
		"superhero" => "Captain Marvel", 
		"negara" => "Amerika Serikat",
		"gambar" => "brie.jpg"
	],

]; 

?>

<?php foreach ($pmr as $avg ) : ?>
	<ul>
		<li>
			<img src="img/<?= $avg["gambar"]; ?>">
		</li>
		<li>Nama : <?= $avg["nama"] ?></li>
		<li>Sebagai : <?= $avg["sebagai"] ?></li>
		<li>Superhero : <?= $avg["superhero"] ?></li>
		<li>Negara : <?= $avg["negara"] ?></li>
	</ul>
<?php endforeach;  ?>



</body>
</html>

